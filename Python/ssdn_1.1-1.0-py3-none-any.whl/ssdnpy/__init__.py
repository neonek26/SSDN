__version__ = "1.0"

from .module1 import *